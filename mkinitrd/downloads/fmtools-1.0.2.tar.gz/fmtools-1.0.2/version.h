#define FMT_VERSION "1.0.2"

