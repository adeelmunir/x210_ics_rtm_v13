
struct bogl_font *bogl_mmap_font(char *file);
