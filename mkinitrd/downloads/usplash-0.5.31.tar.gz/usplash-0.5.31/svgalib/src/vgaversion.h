int vga_version=0x1430;
static char versionstr[32]="1.4.3";
